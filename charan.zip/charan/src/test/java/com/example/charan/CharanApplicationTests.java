package com.example.charan;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CharanApplicationTests {

	@Test
	void contextLoads() {
	}

}
